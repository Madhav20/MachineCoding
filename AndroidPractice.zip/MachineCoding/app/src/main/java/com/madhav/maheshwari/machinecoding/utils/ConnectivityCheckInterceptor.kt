package com.madhav.maheshwari.machinecoding.utils

import android.content.Context
import android.content.Context.CONNECTIVITY_SERVICE
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import javax.inject.Inject

class ConnectivityCheckInterceptor
    @Inject
    constructor(
        private val context: Context,
    ) : Interceptor {
        override fun intercept(chain: Interceptor.Chain): Response {
            return when {
                context.isInternetAvailable() -> {
                    chain.proceed(chain.request())
                }
                else -> {
                    throw ConnectivityException(message = "No Internet Available")
                }
            }
        }
    }

fun Context.isInternetAvailable(): Boolean {
    val connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
    val activeNetwork = connectivityManager.activeNetwork
    val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)

    return networkCapabilities != null && networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

class ConnectivityException(override val message: String) : IOException(message)

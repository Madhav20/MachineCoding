package com.madhav.maheshwari.machinecoding.model

class PlayerResponse : ArrayList<PlayerResponseItem>()
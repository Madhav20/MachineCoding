package com.madhav.maheshwari.machinecoding.components.matches

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.madhav.maheshwari.machinecoding.components.pointstable.PlayerDetailsViewModel
import com.madhav.maheshwari.machinecoding.model.MatchDetailsResponseItem

@Composable
fun MatchDetails(
    playerDetailsViewModel: PlayerDetailsViewModel,
    playerId: Int,
) {
    val matchData = playerDetailsViewModel.getMatchDetailsByPlayerId(playerId)
    Surface(
        color = MaterialTheme.colorScheme.background,
    ) {
        Column {
            Text(
                text = "Matches",
                modifier =
                    Modifier
                        .background(Color.LightGray)
                        .fillMaxWidth()
                        .padding(top = 20.dp),
            )
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
            ) {
                items(matchData.size) { index ->
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .background(
                                    color = getBgColor(playerId, matchData[index]),
                                ).padding(15.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        Text(text = playerDetailsViewModel.getPlayerName(matchData[index].player1.id), fontSize = 16.sp)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(text = matchData[index].player1.score.toString(), fontSize = 16.sp)
                            Text(text = "-", fontSize = 16.sp)
                            Text(text = matchData[index].player2.score.toString(), fontSize = 16.sp)
                        }
                        Text(text = playerDetailsViewModel.getPlayerName(matchData[index].player2.id), fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

fun getBgColor(
    playerId: Int,
    matchDetailsResponseItem: MatchDetailsResponseItem,
): Color {
    if (matchDetailsResponseItem.player1.id == playerId &&
        matchDetailsResponseItem.player1.score > matchDetailsResponseItem.player2.score
    ) {
        return Color.Green
    } else if (matchDetailsResponseItem.player1.id == playerId &&
        matchDetailsResponseItem.player1.score < matchDetailsResponseItem.player2.score
    ) {
        return Color.Red
    }
    return Color.White
}

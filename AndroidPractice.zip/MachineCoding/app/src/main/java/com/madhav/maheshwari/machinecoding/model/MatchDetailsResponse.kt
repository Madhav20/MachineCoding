package com.madhav.maheshwari.machinecoding.model

class MatchDetailsResponse : ArrayList<MatchDetailsResponseItem>()
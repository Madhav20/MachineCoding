package com.madhav.maheshwari.machinecoding.components.pointstable.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.madhav.maheshwari.machinecoding.components.pointstable.PlayerDetailsViewModel
import com.madhav.maheshwari.machinecoding.model.PlayerDetailsUI
import com.madhav.maheshwari.machinecoding.utils.LoadingIndicator
import com.madhav.maheshwari.machinecoding.utils.UIState

@Composable
fun PointsTable(navController: NavController) {
    val viewmodel = hiltViewModel<PlayerDetailsViewModel>()
    val playerDetails by viewmodel.playerDetailsUiState.observeAsState(UIState.None)

    PointsTableView(playerDetails = playerDetails, navController = navController)
}

@Composable
fun PointsTableView(
    playerDetails: UIState<List<PlayerDetailsUI>>,
    navController: NavController,
) {
    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxSize(),
    ) {
        when (playerDetails) {
            is UIState.Error -> {
                Text(text = stringResource(id = playerDetails.message))
            }

            UIState.Loading -> {
                LoadingIndicator()
            }

            UIState.None -> {
            }

            is UIState.Success -> {
                PlayerDetails(playerDetails.data) {
                    navController.navigate("matches/$it")
                }
            }
        }
    }
}

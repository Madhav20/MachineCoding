package com.madhav.maheshwari.machinecoding.components.pointstable.repository

import com.madhav.maheshwari.machinecoding.components.pointstable.PlayerDetailsApi
import com.madhav.maheshwari.machinecoding.model.PlayerResponse
import com.madhav.maheshwari.machinecoding.utils.DispatcherProvider
import com.madhav.maheshwari.machinecoding.utils.NetworkCall
import com.madhav.maheshwari.machinecoding.utils.Status
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

class PointsTableRepositoryImpl
    @Inject
    constructor(
        private val api: PlayerDetailsApi,
        private val dispatcherProvider: DispatcherProvider,
    ) : PointsTableRepository {
        private val scope = CoroutineScope(dispatcherProvider.io)

        override suspend fun getPlayerDetails(): Flow<Status<PlayerResponse>> =
            NetworkCall
                .performNetworkApiCall {
                    api.getPlayersDetails()
                }.stateIn(scope, SharingStarted.Lazily, Status.Loading)
    }

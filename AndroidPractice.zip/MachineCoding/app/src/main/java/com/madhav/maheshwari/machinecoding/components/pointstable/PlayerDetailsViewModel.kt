package com.madhav.maheshwari.machinecoding.components.pointstable

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.madhav.maheshwari.machinecoding.R
import com.madhav.maheshwari.machinecoding.components.matches.repository.MatchDetailsRepository
import com.madhav.maheshwari.machinecoding.components.pointstable.repository.PointsTableRepository
import com.madhav.maheshwari.machinecoding.model.MatchDetailsResponse
import com.madhav.maheshwari.machinecoding.model.MatchDetailsResponseItem
import com.madhav.maheshwari.machinecoding.model.PlayerDetailsUI
import com.madhav.maheshwari.machinecoding.model.PlayerResponse
import com.madhav.maheshwari.machinecoding.model.PlayerResponseItem
import com.madhav.maheshwari.machinecoding.model.getPlayerDetails
import com.madhav.maheshwari.machinecoding.utils.DispatcherProvider
import com.madhav.maheshwari.machinecoding.utils.ResponseCode
import com.madhav.maheshwari.machinecoding.utils.Status
import com.madhav.maheshwari.machinecoding.utils.UIState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlayerDetailsViewModel
    @Inject
    constructor(
        private val repository: PointsTableRepository,
        private val matchDetailsRepository: MatchDetailsRepository,
        private val dispatcherProvider: DispatcherProvider,
    ) : ViewModel() {
        private val _playerDetailsUiState = MutableLiveData<UIState<List<PlayerDetailsUI>>>(UIState.Loading)
        val playerDetailsUiState: LiveData<UIState<List<PlayerDetailsUI>>> = _playerDetailsUiState
        private val playerPoints = mutableMapOf<Int, Int>()

        private val matchResponse = MutableLiveData<List<MatchDetailsResponseItem>>()
        private val playerDetails = MutableLiveData<List<PlayerResponseItem>>()
        val matchDetails = MutableLiveData<List<MatchDetailsResponse>>()

        init {
            viewModelScope.launch(dispatcherProvider.io) {
                repository.getPlayerDetails().collectLatest {
                    when (it) {
                        Status.Loading -> {
                            _playerDetailsUiState.postValue(UIState.Loading)
                        }
                        is Status.OnFailed -> {
                            _playerDetailsUiState.postValue(UIState.Error(R.string.something_went_wrong, ResponseCode.UNKNOWN_ERROR))
                        }
                        is Status.OnSuccess -> {
                            playerDetails.postValue(it.response)
                            getMatchDetails(it.response)
                        }
                    }
                }
            }
        }

        private fun getMatchDetails(response: PlayerResponse) {
            viewModelScope.launch(dispatcherProvider.io) {
                matchDetailsRepository.getMatchDetails().collectLatest {
                    when (it) {
                        Status.Loading -> {
                            _playerDetailsUiState.postValue(UIState.Loading)
                        }
                        is Status.OnFailed -> {
                            _playerDetailsUiState.postValue(UIState.Error(R.string.something_went_wrong, ResponseCode.UNKNOWN_ERROR))
                        }
                        is Status.OnSuccess -> {
                            matchResponse.postValue(it.response)
                            it.response.forEach { match ->
                                val player1 = match.player1
                                val player2 = match.player2
                                when {
                                    player1.score > player2.score -> {
                                        playerPoints[player1.id] = playerPoints.getOrDefault(player1.id, 0) + 3
                                    }
                                    player1.score < player2.score -> {
                                        playerPoints[player2.id] = playerPoints.getOrDefault(player2.id, 0) + 3
                                    }
                                    else -> {
                                        playerPoints[player1.id] = playerPoints.getOrDefault(player1.id, 0) + 1
                                        playerPoints[player2.id] = playerPoints.getOrDefault(player2.id, 0) + 1
                                    }
                                }
                            }
                            val data = getPlayerDetails(response)
                            _playerDetailsUiState.postValue(UIState.Success(data))
                        }
                    }
                }
            }
        }

        private fun getPlayerDetails(response: PlayerResponse): List<PlayerDetailsUI> =
            response
                .map { player ->
                    player.getPlayerDetails(playerPoints[player.id])
                }.sortedByDescending {
                    it.score
                }

        fun getMatchDetailsByPlayerId(playerId: Int): List<MatchDetailsResponseItem> =
            matchResponse.value?.filter {
                it.player1.id == playerId || it.player2.id == playerId
            } ?: listOf()

        fun getPlayerName(playerId: Int): String  {
            playerDetails.value?.forEach {
                if (it.id == playerId) {
                    return it.name
                }
            }
            return ""
        }
    }

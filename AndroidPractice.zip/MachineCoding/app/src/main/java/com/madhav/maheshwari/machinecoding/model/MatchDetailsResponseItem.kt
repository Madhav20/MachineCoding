package com.madhav.maheshwari.machinecoding.model

data class MatchDetailsResponseItem(
    val match: Int,
    val player1: Player,
    val player2: Player,
)

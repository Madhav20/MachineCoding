package com.madhav.maheshwari.machinecoding.model

data class PlayerResponseItem(
    val icon: String,
    val id: Int,
    val name: String
)
package com.madhav.maheshwari.machinecoding.components.pointstable
import com.madhav.maheshwari.machinecoding.model.PlayerResponse
import retrofit2.Response
import retrofit2.http.GET

interface PlayerDetailsApi {
    @GET("IKQQ")
    suspend fun getPlayersDetails(): Response<PlayerResponse>
}

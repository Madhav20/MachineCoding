package com.madhav.maheshwari.machinecoding.components.matches.repository

import com.madhav.maheshwari.machinecoding.components.matches.MatchDetailsApi
import com.madhav.maheshwari.machinecoding.model.MatchDetailsResponse
import com.madhav.maheshwari.machinecoding.utils.DispatcherProvider
import com.madhav.maheshwari.machinecoding.utils.NetworkCall
import com.madhav.maheshwari.machinecoding.utils.Status
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

class MatchDetailsRepositoryImpl
    @Inject
    constructor(
        private val matchDetailsApi: MatchDetailsApi,
        private val dispatcherProvider: DispatcherProvider,
    ) : MatchDetailsRepository {
        private val scope = CoroutineScope(dispatcherProvider.io)

        override suspend fun getMatchDetails(): Flow<Status<MatchDetailsResponse>> =
            NetworkCall
                .performNetworkApiCall {
                    matchDetailsApi.getMatchDetails()
                }.stateIn(scope, SharingStarted.Lazily, Status.Loading)
    }

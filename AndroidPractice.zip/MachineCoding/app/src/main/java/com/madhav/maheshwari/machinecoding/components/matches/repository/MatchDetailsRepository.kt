package com.madhav.maheshwari.machinecoding.components.matches.repository

import com.madhav.maheshwari.machinecoding.model.MatchDetailsResponse
import com.madhav.maheshwari.machinecoding.utils.Status
import kotlinx.coroutines.flow.Flow

interface MatchDetailsRepository {
    suspend fun getMatchDetails(): Flow<Status<MatchDetailsResponse>>
}

package com.madhav.maheshwari.machinecoding.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.retryWhen
import retrofit2.Response
import java.io.IOException

typealias NetworkAPIInvoke<T> = suspend () -> Response<T>

object NetworkCall {
    suspend fun <T : Any> performNetworkApiCall(
        allowRetries: Boolean = true,
        numberOfRetries: Int = 2,
        networkApiCall: NetworkAPIInvoke<T>,
    ): Flow<Status<T>> {
        var delayDuration = 1000L
        val delayFactor = 2
        return flow {
            val response = networkApiCall()
            if (response.isSuccessful) {
                response.body()?.let {
                    emit(Status.OnSuccess(it))
                } ?: emit(
                    Status.OnFailed(
                        Throwable(message = response.message()),
                        code = ResponseCode.EMPTY_BODY,
                    ),
                )
                return@flow
            }

            emit(
                Status.OnFailed(
                    Throwable(message = response.message()),
                    ResponseCode.UNKNOWN_ERROR
                )
            )
            return@flow
        }.catch { error ->
            when (error) {
                is ConnectivityException ->
                    emit(
                        Status.OnFailed(
                            Throwable(message = "No Internet connection"),
                            ResponseCode.INTERNET_NOT_AVAILABLE,
                        ),
                    )
                else ->
                    emit(
                        Status.OnFailed(
                            error,
                            ResponseCode.UNKNOWN_ERROR,
                        ),
                    )
            }
            return@catch
        }.retryWhen { cause, attempt ->
            if (!allowRetries || attempt > numberOfRetries || cause !is IOException) return@retryWhen false
            delay(delayDuration)
            delayDuration *= delayFactor
            return@retryWhen true
        }.flowOn(Dispatchers.IO)
    }
}

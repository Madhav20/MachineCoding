package com.madhav.maheshwari.machinecoding.di

import android.content.Context
import com.madhav.maheshwari.machinecoding.components.matches.MatchDetailsApi
import com.madhav.maheshwari.machinecoding.components.matches.repository.MatchDetailsRepository
import com.madhav.maheshwari.machinecoding.components.matches.repository.MatchDetailsRepositoryImpl
import com.madhav.maheshwari.machinecoding.components.pointstable.PlayerDetailsApi
import com.madhav.maheshwari.machinecoding.components.pointstable.repository.PointsTableRepository
import com.madhav.maheshwari.machinecoding.components.pointstable.repository.PointsTableRepositoryImpl
import com.madhav.maheshwari.machinecoding.utils.ConnectivityCheckInterceptor
import com.madhav.maheshwari.machinecoding.utils.Constants
import com.madhav.maheshwari.machinecoding.utils.DispatcherProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.*
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Singleton
    @Provides
    fun provideDispatchers(): DispatcherProvider =
        object : DispatcherProvider {
            override val main: CoroutineDispatcher
                get() = Dispatchers.Main
            override val io: CoroutineDispatcher
                get() = Dispatchers.IO
            override val default: CoroutineDispatcher
                get() = Dispatchers.Default
            override val unconfined: CoroutineDispatcher
                get() = Dispatchers.Unconfined
        }

    @Provides
    @Singleton
    fun provideRetrofit(
        @ApplicationContext context: Context,
    ): Retrofit =
        Retrofit
            .Builder()
            .baseUrl(Constants.BASE_URL)
            .client(provideOkHttpClient(context))
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    private fun provideOkHttpClient(
        @ApplicationContext context: Context,
    ): OkHttpClient =
        OkHttpClient
            .Builder()
            .readTimeout(20L, TimeUnit.SECONDS)
            .apply {
                val httpLoggingInterceptor =
                    HttpLoggingInterceptor()
                httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.HEADERS)

                httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
                addNetworkInterceptor(httpLoggingInterceptor)
                addInterceptor(ConnectivityCheckInterceptor(context))
            }.build()

    @Provides
    @Singleton
    fun providePlayerDetailsApi(retrofit: Retrofit) = retrofit.create(PlayerDetailsApi::class.java)

    @Provides
    @Singleton
    fun provideChatRepository(
        api: PlayerDetailsApi,
        dispatcherProvider: DispatcherProvider,
    ): PointsTableRepository = PointsTableRepositoryImpl(api, dispatcherProvider)

    @Provides
    @Singleton
    fun provideMatchDetailsApi(retrofit: Retrofit) = retrofit.create(MatchDetailsApi::class.java)

    @Provides
    @Singleton
    fun provideMatchDetailsRepository(
        api: MatchDetailsApi,
        dispatcherProvider: DispatcherProvider,
    ): MatchDetailsRepository = MatchDetailsRepositoryImpl(api, dispatcherProvider)
}

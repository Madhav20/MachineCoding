package com.madhav.maheshwari.machinecoding

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.madhav.maheshwari.machinecoding.components.matches.MatchDetails
import com.madhav.maheshwari.machinecoding.components.pointstable.PlayerDetailsViewModel
import com.madhav.maheshwari.machinecoding.components.pointstable.ui.PointsTable
import com.madhav.maheshwari.machinecoding.ui.theme.MachineCodingTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MachineCodingTheme {
                Surface(
                    color = MaterialTheme.colorScheme.background,
                ) {
                    AppNavigator()
                }
            }
        }
    }
}

@Composable
fun AppNavigator() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "pointsTable") {
        composable("pointsTable") {
            PointsTable(navController = navController)
        }

        composable("matches/{playerId}", arguments = listOf(navArgument("playerId") { type = NavType.IntType })) { backStackEntry ->
            val playerId = backStackEntry.arguments?.getInt("playerId") ?: -1

            val parentEntry =
                remember(backStackEntry) {
                    navController.getBackStackEntry("pointsTable")
                }
            val viewModel = hiltViewModel<PlayerDetailsViewModel>(parentEntry)
            MatchDetails(viewModel, playerId)
        }
    }
}

package com.madhav.maheshwari.machinecoding.model

data class Player(
    val id: Int,
    val score: Int,
)

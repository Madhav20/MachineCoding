package com.madhav.maheshwari.machinecoding.model

import java.io.Serializable

data class PlayerDetailsUI(
    var id: Int,
    var name: String,
    var icon: String,
    var score: Int? = 0,
) : Serializable

fun PlayerResponseItem.getPlayerDetails(score: Int?) =
    PlayerDetailsUI(
        id = id,
        name = name,
        icon = icon,
        score = score,
    )

package com.madhav.maheshwari.machinecoding.components.pointstable.repository

import com.madhav.maheshwari.machinecoding.model.PlayerResponse
import com.madhav.maheshwari.machinecoding.utils.Status
import kotlinx.coroutines.flow.Flow

interface PointsTableRepository {
    suspend fun getPlayerDetails(): Flow<Status<PlayerResponse>>
}

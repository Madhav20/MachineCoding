package com.madhav.maheshwari.machinecoding.components.matches

import com.madhav.maheshwari.machinecoding.model.MatchDetailsResponse
import retrofit2.Response
import retrofit2.http.GET

interface MatchDetailsApi {
    @GET("JNYL")
    suspend fun getMatchDetails(): Response<MatchDetailsResponse>
}

package com.madhav.maheshwari.machinecoding.utils

// Use this class to keep constants in the app
object Constants {
    const val BASE_URL = "https://www.jsonkeeper.com/b/"
}

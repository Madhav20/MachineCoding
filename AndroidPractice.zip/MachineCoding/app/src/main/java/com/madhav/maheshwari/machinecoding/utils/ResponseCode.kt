package com.madhav.maheshwari.machinecoding.utils

object ResponseCode {
    const val EMPTY_BODY = 101
    const val UNKNOWN_ERROR = 102
    const val INTERNET_NOT_AVAILABLE = 103
}
